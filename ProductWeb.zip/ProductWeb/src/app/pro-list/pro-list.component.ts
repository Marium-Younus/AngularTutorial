import { Component } from '@angular/core';

@Component({
  selector: 'app-pro-list',
  templateUrl: './pro-list.component.html',
  styleUrl: './pro-list.component.css'
})
export class ProListComponent  {
  flower =[
    {name:'Rose',description:'Rose Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, quo. Lorem ipsum dolor sit amet consectetur.',image:'rose.jpg'},
    {name:'Lilly',description:'Lilly Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, quo. Lorem ipsum dolor sit amet consectetur.',image:'lily.jpg'},
    {name:'Lotus',description: ' Lotus Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, quo. Lorem ipsum dolor sit amet consectetur.',image:'lotus.jpg'},
    {name:'Jasmine',description:'Jasmine Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, quo. Lorem ipsum dolor sit amet consectetur.',image:'jasmine.jpg'},
    {name:'Sunflower',description:'Sunflower Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, quo. Lorem ipsum dolor sit amet consectetur.',image:'sunflower.jpg'},
    {name:'Daisy',description:'Daisey Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, quo. Lorem ipsum dolor sit amet consectetur.',image:'daisy.jpg'}
]
//----------------------------------------
searchText=''
  constructor() {
   this.searchText = '';
  }
}
