import { Component } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent {
  btnclick(){
    alert("Hello Click event invoked")
  }
  getdata(val:string){
    //alert(val)
    console.log(val)
  }
  kddata(str:string){
    //alert(str)
    console.log(str)
  }
  kbdata(a:string){
    //alert(a)
    console.log(a)
  }
  mo_data(){
    alert("Mouse over Invoked")
  }
  ml_data(){
    alert("Mouse leave Invoked")
  }
  displayname = ''
  getvalue(a:string){
      console.log(a)
      this.displayname = a
  }

  fullname = ''
  btn_clik(b:string){
    console.log(b)
    this.fullname =b
  }
}
