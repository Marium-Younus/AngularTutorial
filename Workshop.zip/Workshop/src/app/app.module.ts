import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserListComponent } from './user-list/user-list.component';
import { AngularDirectComponent } from './angular-direct/angular-direct.component';
import { TodoListComponent } from './todo-list/todo-list.component';
import { LoopWorkComponent } from './loop-work/loop-work.component';
import { BasicFormComponent } from './basic-form/basic-form.component';
@NgModule({
  declarations: [
    AppComponent,
    UserListComponent,
    AngularDirectComponent,
    TodoListComponent,
    LoopWorkComponent,
    BasicFormComponent,
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
