import { Component } from '@angular/core';

@Component({
  selector: 'app-angular-direct',
  templateUrl: './angular-direct.component.html',
  styleUrl: './angular-direct.component.css'
})
export class AngularDirectComponent {
  mycolor="purple"
  
  // color='blue'
 /*show=true
  data = 'yes'*/



// name='Angular Turtorial'
// ischeck = false

}

 