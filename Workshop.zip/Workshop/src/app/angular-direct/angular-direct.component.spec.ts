import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularDirectComponent } from './angular-direct.component';

describe('AngularDirectComponent', () => {
  let component: AngularDirectComponent;
  let fixture: ComponentFixture<AngularDirectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AngularDirectComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AngularDirectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
