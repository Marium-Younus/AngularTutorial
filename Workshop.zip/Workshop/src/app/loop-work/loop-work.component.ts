import { Component, OnInit, Output } from '@angular/core';
import { EventEmitter } from 'node:stream';

@Component({
  selector: 'app-loop-work',
  templateUrl: './loop-work.component.html',
  styleUrl: './loop-work.component.css'
})
export class LoopWorkComponent {
 
fullname ="Marium Younus"
fulldate = Date()
employee = ["Jhon",'David','Charlie','Jassica','Sara','Tom','Ethin']
searchText:any;
studentdetail =[
    {id:1,name:'Muhammad Faisal',subject:'HTML',image:'team-1.jpg'},
    {id:2,name:'Muhammad Ahmed',subject:'Dart',image:'team-2.jpg'},
    {id:3,name:'Ramsha Sohail',subject:'CSS',image:'team-3.jpg'},
    {id:4,name:'Sameer Khan',subject:'Java',image:'team-2.jpg'},
    {id:5,name:'Samra Mubashir',subject:'Python',image:'team-4.jpg'}
]
//----------------------------nested loop

teacher =[
    {t_name:'Sir Usama Riaz',t_phone:'03214678291',t_skills:["PHP",'MYSQL','Adobe Illustrator','Adobe Photoshop']},
    {t_name:'Miss Marium Younus',t_phone:'0114636231',t_skills:["Python",'R-Programming','Machine Learning','NLP']},
    {t_name:'Miss Sadia Fahim',t_phone:'03214678291',t_skills:["C#",'ASP.Net Core','Android']},
    {t_name:'Sir Bilal',t_phone:'03342678291',t_skills:["HTML",'C','Java','C#','Asp.Net']}]



}
