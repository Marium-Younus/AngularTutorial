import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoopWorkComponent } from './loop-work.component';

describe('LoopWorkComponent', () => {
  let component: LoopWorkComponent;
  let fixture: ComponentFixture<LoopWorkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LoopWorkComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LoopWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
